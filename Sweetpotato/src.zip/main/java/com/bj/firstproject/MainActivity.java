package com.bj.firstproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity<mAuth> extends AppCompatActivity {
    private FirebaseAuth firebaseAuth;
    private FirebaseUser currentUser;

    private GoogleSignInClient mGoogleSignInClient;
    private static final int RC_SIGN_IN = 9001;
    EditText etemail_input, etpassword_input;
    private Button btngoogle;

    Button btnlogin; Button btnjoin; Button btnsearch;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        firebaseAuth =  FirebaseAuth.getInstance();


        etemail_input = findViewById(R.id.etemail_input);
        etpassword_input = findViewById(R.id.etpassword_input);
        btnlogin = findViewById(R.id.btnlogin);
        btnjoin = findViewById(R.id.btnjoin);
        btnsearch = findViewById(R.id.btnjoin);
        btngoogle = findViewById(R.id.btngoogle);
        findViewById(R.id.btnjoin).setOnClickListener(mClick);
        findViewById(R.id.btnlogin).setOnClickListener(mClick);
        findViewById(R.id.btnsearch).setOnClickListener(mClick);
        findViewById(R.id.btngoogle).setOnClickListener(mClick);

        currentUser = firebaseAuth.getCurrentUser();

        if(currentUser != null){
            if (currentUser.getPhotoUrl() !=null) {
                Log.d("check", "로그인 되어있습니다.");
                startActivity(new Intent(MainActivity.this, HomeActivity.class));
                finish();
            }
        }
    }



        View.OnClickListener mClick = new View.OnClickListener() {
            public void onClick(View v) {
                switch (v.getId())
                    {
                        case R.id.btnjoin:
                            Intent ex1 = new Intent(MainActivity.this, Sign_up.class);
                            startActivity(ex1);
                            break;
                        case R.id.btnlogin:
                            login(); break;
                        case R.id.btnsearch:
                            Intent search = new Intent(MainActivity.this, SearchActivity.class);
                            startActivity(search);
                            break;
                        case R.id.btngoogle:
                            googlelogin(); break;
                    }
                }

        };

    private void login() {


        final ProgressDialog mDialog = new ProgressDialog(MainActivity.this);
        mDialog.setMessage("로그인중입니다...");
        mDialog.show();
                String email = etemail_input.getText().toString().trim();
                String pwd = etpassword_input.getText().toString().trim();
                if(email.equals("")){
                    Toast.makeText(MainActivity.this, "email을 입력해주세요", Toast.LENGTH_SHORT).show();
                    mDialog.dismiss(); return;
                }else if(pwd.equals("")){
                    Toast.makeText(MainActivity.this, "비밀번호를 입력해주세요", Toast.LENGTH_SHORT).show();
                    mDialog.dismiss(); return;
                }else {
                    firebaseAuth.signInWithEmailAndPassword(email, pwd)
                            .addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {
                                        Intent ex2 = new Intent(MainActivity.this, Sign_up_profile2.class);
                                        startActivity(ex2);
                                        mDialog.dismiss();

                                    } else {
                                        Toast.makeText(MainActivity.this, "email과 비밀번호를 확인해주세요", Toast.LENGTH_SHORT).show();
                                        mDialog.dismiss();
                                    }
                                }
                            });
                }
    }
    public void googlelogin(){
        Intent google_login = new Intent(MainActivity.this, Sign_up_google.class);
        startActivity(google_login);
    }


}

