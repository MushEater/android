package com.bj.firstproject;

import static android.content.ContentValues.TAG;

import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.content.CursorLoader;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.annotations.Nullable;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.File;
import java.util.HashMap;
import java.util.Map;


public class upload_vs extends AppCompatActivity {


    public static class PostModel2 {

        public String myid; // 로그인한 아이디
        public String photo1; // 게시글 사진
        public String photo2; // 게시글 사진
        public String photoName1; // 게시글사진 이름(사진삭제할때 필요, 절대경로를 뜻함)
        public String photoName2; // 게시글사진 이름(사진삭제할때 필요, 절대경로를 뜻함)
        public String contents; // 게시글 내용
        //        public String person; // 친구태그
        public String userprofileimage; // 회원가입시 프로필사진
        public String username; // 회원가입시 닉네임
        public int starCount = 0; // 좋아요 갯수
        public float starall = 0; //별점 총합
        public float star = starall/starCount; // 평균 별점
        public String comment;
        public Map<String, Boolean> stars = new HashMap<>(); // 별점 매긴사람
        // String 값은 아이디를 뜻하고, boolean 은 true

    }
    int select;
    public static final int PICK_FROM_ALBUM = 1;
    private Uri imageUri1; private Uri imageUri2;
    private String pathUri1; private String pathUri2;
    private File tempFile;
    private FirebaseAuth mAuth;
    private FirebaseDatabase mDatabase;
    private FirebaseStorage mStorage;
    private Button btn_upload_vs;
    ImageView iv_upload_vs1; ImageView iv_upload_vs2;
    EditText et_post_upload_vs;
    String imageName2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.upload_vs);


        // Authentication, Database, Storage 초기화
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        String name = user.getDisplayName();
        String email = user.getEmail();
        Uri photoUrl1 = user.getPhotoUrl();
        Uri photoUrl2 = user.getPhotoUrl();


        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance();
        mStorage = FirebaseStorage.getInstance();

        // 변수 할당
        et_post_upload_vs = findViewById(R.id.et_post_upload_vs);
        iv_upload_vs1 = (ImageView) findViewById(R.id.iv_upload_vs1);
        iv_upload_vs2 = (ImageView) findViewById(R.id.iv_upload_vs2);
        btn_upload_vs = findViewById(R.id.btn_upload_vs);




        iv_upload_vs1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoAlbum(); select = 1;
                Log.d("check", "앨범가기");
            }
        });
        iv_upload_vs2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoAlbum(); select = 2;
                Log.d("check", "앨범가기");
            }
        });








        et_post_upload_vs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("check", "ㅎㅇ");
                upload();
            }
        });
    }
    // 앨범 메소드
    private void gotoAlbum() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType(MediaStore.Images.Media.CONTENT_TYPE);
        startActivityForResult(intent, PICK_FROM_ALBUM);
        Log.d("check", "앨범들어옴");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK) { // 코드가 틀릴경우
            Toast.makeText(upload_vs.this, "취소되었습니다.", Toast.LENGTH_SHORT).show();
            if (tempFile != null) {
                if (tempFile.exists()) {
                    if (tempFile.delete()) {
                        Log.e(TAG, tempFile.getAbsolutePath() + " 삭제 성공");
                        tempFile = null;
                    }
                }
            }
            return;
        }

        switch (requestCode) {
            case PICK_FROM_ALBUM: { // 코드 일치
                // Uri
                if(select==1) {
                    imageUri1 = data.getData();
                    Intent intent = new Intent(upload_vs.this, upload_vs.class);
                    intent.putExtra("문자", imageUri1); //'문자'라는 이름으로 main_text 전달
                    pathUri1 = getPath(data.getData());
                    Log.d("check", "pick from album" + imageUri1);
//                photo_profile.setImageURI(imageUri); // 이미지 띄움
                    iv_upload_vs1.setImageURI(imageUri1);
                    break;
                }else if(select==2){
                    imageUri2 = data.getData();
                    Intent intent = new Intent(upload_vs.this, upload_vs.class);
                    intent.putExtra("문자", imageUri2); //'문자'라는 이름으로 main_text 전달
                    pathUri2 = getPath(data.getData());
                    Log.d("check", "pick from album" + imageUri2);
//                photo_profile.setImageURI(imageUri); // 이미지 띄움
                    iv_upload_vs2.setImageURI(imageUri2);



                }
            }
        }
    }
    // uri 절대경로 가져오기
    public String getPath(Uri uri) {

        String[] proj = {MediaStore.Images.Media.DATA};
        CursorLoader cursorLoader = new CursorLoader(this, uri, proj, null, null, null);
        Log.d("절대경로", "지나감");
        Cursor cursor = cursorLoader.loadInBackground();
        int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        return cursor.getString(columnIndex);
    }

    public void upload() {
        final ProgressDialog mDialog = new ProgressDialog(upload_vs.this);
        mDialog.setMessage("글 작성중입니다.");
        mDialog.show();


        String c = et_post_upload_vs.getText().toString(); // 게시글


        final String uid = mAuth.getCurrentUser().getUid();
        final Uri file1 = Uri.fromFile(new File(pathUri1)); // 절대경로uri를 file에 할당
        Log.d(TAG, "phto file : " + file1);

        StorageReference storageReference = mStorage.getReference().child("userImages").child("uid/" + file1.getLastPathSegment());
        storageReference.putFile(imageUri1).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                final Task<Uri> imageUrl1 = task.getResult().getStorage().getDownloadUrl();
                while (!imageUrl1.isComplete()) ;

                mDatabase.getReference().child("users").child(uid)
                        .addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                Sign_up_profile.UserModel userModel = dataSnapshot.getValue(Sign_up_profile.UserModel.class);
                                Log.d(TAG, "profileImageUrl" + userModel.profileImageUrl);
                                Log.d(TAG, "userName" + userModel.userName);

                                upload_vs.PostModel2 postModel2 = new upload_vs.PostModel2();
                                Log.d("check", "PostModel 생성");
                                postModel2.myid = uid;
                                postModel2.photo1 = imageUrl1.getResult().toString();
                                postModel2.userprofileimage = userModel.profileImageUrl;
                                postModel2.photoName1 = file1.getLastPathSegment();
                                postModel2.contents = c;
                                postModel2.username = userModel.userName;
                                postModel2.star = 0;
                                // 게시글 내용 저장
                                mDatabase.getReference().child("contents").child("vs").push()
                                        .setValue(postModel2).addOnSuccessListener(new OnSuccessListener<Void>() {
                                            @Override
                                            public void onSuccess(Void aVoid) {
                                                Intent uploadfinish = new Intent(upload_vs.this, HomeActivity.class);
                                                startActivity(uploadfinish);
                                                Toast.makeText(upload_vs.this, "글 작성에 성공했습니다.", Toast.LENGTH_SHORT).show();
                                                mDialog.dismiss();
                                                Log.d("check", "게시글 내용 저장성공");
                                                finish();
                                            }
                                        });
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                Toast.makeText(upload_vs.this, "오류로인해 실패했습니다..", Toast.LENGTH_SHORT).show();
                                mDialog.dismiss();
                            }
                        });

            }
        });




    }

}