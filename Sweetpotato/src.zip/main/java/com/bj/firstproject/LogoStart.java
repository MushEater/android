package com.bj.firstproject;

import android.animation.Animator;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.airbnb.lottie.LottieAnimationView;
import com.airbnb.lottie.animation.keyframe.BaseKeyframeAnimation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.Timer;
import java.util.TimerTask;


public class LogoStart extends AppCompatActivity {

    private static final String TAG = "FindActivity";
    EditText et_send_email;
    Button btnsend_email;
    private FirebaseAuth firebaseAuth;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.logostart);





        firebaseAuth = FirebaseAuth.getInstance();
        LottieAnimationView animationView = findViewById(R.id.logo_animation);
        animationView.setSpeed(1f);

        animationView.setVisibility(View.VISIBLE);
        animationView.playAnimation();
        animationView.addAnimatorListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animator) {
            }

            @Override
            public void onAnimationEnd(Animator animator) {
                animationView.setVisibility(View.GONE);
                startapp();
            }

            @Override
            public void onAnimationCancel(Animator animator) {

            }

            @Override
            public void onAnimationRepeat(Animator animator) {

            }
        });



    }




    public void startapp() {

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        if (user != null) {
            // Name, email address, and profile photo Url
            if (user.getPhotoUrl() !=null) {
                Toast.makeText(LogoStart.this, "로그인 되어있음", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(LogoStart.this, HomeActivity.class));
                finish();
            }
        }
        else {
            // Name, email address, and profile photo Url

            Toast.makeText(LogoStart.this, "로그인 해주세요", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(LogoStart.this, MainActivity.class));
            finish();
        }
    }

}