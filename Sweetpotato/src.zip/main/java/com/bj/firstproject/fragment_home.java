package com.bj.firstproject;

import static android.content.ContentValues.TAG;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.bj.firstproject.recycle.CustomAdapter;
import com.bj.firstproject.recycle.User;
import com.bj.firstproject.recycle.cards;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.annotations.Nullable;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.ArrayList;
import java.util.List;


public class fragment_home extends Fragment  {

    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private ArrayList<User> arrayList;
    private FirebaseDatabase database;
    private DatabaseReference databaseReference;
    private View view;
    private FirebaseAuth mAuth;


    private String currentUId;
    private DatabaseReference usersDb;
    Button btn_comment;
    EditText et_comment;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_home, container, false);

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        mAuth = FirebaseAuth.getInstance();

        recyclerView = view.findViewById(R.id.recyclerView); // 아이디 연결
        recyclerView.setHasFixedSize(true); // 리사이클러뷰 기존 성능 강화
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        arrayList = new ArrayList<>(); // User 객체를 어댑터 쪽으로 담을 어레이 리스트

        database = FirebaseDatabase.getInstance(); // 파이어베이스 데이터베이스 연동

        databaseReference = database.getReference("contents").child("content"); // DB 테이블 연결
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // 파이어베이스 데이터베이스의 데이터를 받아오는 곳
                arrayList.clear(); // 기존 배열리스트가 존재하지 않게 초기화
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) { //반복문으로 데이터 리스트를 추출
                    User user = snapshot.getValue(User.class); // User 객체에 데이터 담는다
                    arrayList.add(user); // 담은 데이터들을 배열리스트에 넣고 리사이클러뷰로 보낼 준비
                }
                adapter.notifyDataSetChanged(); // 리스트 저장 및 새로고침
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // db를 가져오던 중 에러 발생 시
                Log.e("MainActivity", String.valueOf(error.toException())); // 에러문 출력
            }
        });


        adapter = new CustomAdapter(arrayList, getActivity());


//        LayoutInflater layoutInflater = (LayoutInflater)getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
//        View view2 = layoutInflater.inflate(R.layout.post_item, null);  // fragment에서 post_item 레이아웃 위젯 사용


        
        
        recyclerView.setAdapter(adapter); // 리사이클러뷰에 어댑터 연결






        et_comment = (EditText) view.findViewById(R.id.et_comment);
        btn_comment = (Button) view.findViewById(R.id.btn_comment); //fragment에서 findViewByid는 view.을 이용해서 사용





        return view;
    }

    public void comment(){

        final ProgressDialog mDialog = new ProgressDialog(getActivity());
        mDialog.setMessage("글 작성중입니다.");
        mDialog.show();


        String comment = et_comment.getText().toString(); // 댓글
        final String uid = mAuth.getCurrentUser().getUid();





        database.getReference().child("users").child(uid)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        Sign_up_profile.UserModel userModel = dataSnapshot.getValue(Sign_up_profile.UserModel.class);
                        Log.d(TAG, "profileImageUrl" + userModel.profileImageUrl);
                        Log.d(TAG, "userName" + userModel.userName);

                        upload.PostModel postModel = new upload.PostModel();
                        Log.d("check", "PostModel 생성");
                        postModel.myid = uid;
                        postModel.userprofileimage = userModel.profileImageUrl;
                        postModel.comment = comment;
                        postModel.username = userModel.userName;

                        // 게시글 내용 저장
                        database.getReference().child("contents").child("content").push()
                                .setValue(postModel).addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {

                                        Toast.makeText(getActivity(), "댓글 작성에 성공했습니다.", Toast.LENGTH_SHORT).show();
                                        mDialog.dismiss();
                                        Log.d("check", "게시글 내용 저장성공");

                                    }
                                });
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(getActivity(), "오류로인해 실패했습니다..", Toast.LENGTH_SHORT).show();
                        mDialog.dismiss();
                    }
                });




    }


}
