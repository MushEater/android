package com.bj.firstproject;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;

import de.hdodenhof.circleimageview.CircleImageView;

public class HomeActivity extends AppCompatActivity {


    private File tempFile;
    private Uri imageUri;
    private FirebaseAuth mAuth;
    private String pathUri;
    private FirebaseDatabase mDatabase;
    private FirebaseStorage mStorage;
    CircleImageView my_profile_image;
    String imageName;
    Button btn_popul; Button btn_exploer;

    FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();



    // Name, email address, and profile photo Url
    String name = user.getDisplayName();
    String email = user.getEmail();
    Uri uri= user.getPhotoUrl();
    fragment_home fragment_home; fragment_search fragment_search; fragment_updown fragment_updown;
    fragment_mypage fragment_mypage;
    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);

        fragment_home =new fragment_home(); fragment_search = new fragment_search();
        fragment_updown = new fragment_updown(); fragment_mypage = new fragment_mypage();
        getSupportFragmentManager().beginTransaction().replace(R.id.frame_bottom_navi, fragment_home).commit();



        BottomNavigationView bottom_menu = findViewById(R.id.bottomNavigationView);
        bottom_menu.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch(item.getItemId()) {
                    case R.id.tab_home:
                        getSupportFragmentManager().beginTransaction().replace(R.id.frame_bottom_navi, fragment_home).commit();
                        return true;
                    case R.id.tab_search:
                        Log.d("check", "search로 이동");
                        getSupportFragmentManager().beginTransaction().replace(R.id.frame_bottom_navi, fragment_search).commit();
                        return true;
                    case R.id.tab_updown:
                        getSupportFragmentManager().beginTransaction().replace(R.id.frame_bottom_navi, fragment_updown).commit();
                        return true;
                    case R.id.tab_mypage:
                        getSupportFragmentManager().beginTransaction().replace(R.id.frame_bottom_navi, fragment_mypage).commit();
                        return true;
                }
                return false;
            }
        });




        Intent intent32 = getIntent();
        imageName = intent32.getStringExtra("문자");
        Log.d("홈2","값2:" + imageName);
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance();
        mStorage = FirebaseStorage.getInstance();

        my_profile_image = (CircleImageView) findViewById(R.id.my_profile_image);




            // Check if user's email is verified
            boolean emailVerified = user.isEmailVerified();

            // The user's ID, unique to the Firebase project. Do NOT use this value to
            // authenticate with your backend server, if you have one. Use
            // FirebaseUser.getIdToken() instead.
            String uid = user.getUid();
            Toast.makeText(HomeActivity.this, name + "님 환영합니다.", Toast.LENGTH_SHORT).show();

            Log.d("check", "홈"+uri);
            downloadImg();



    }


        View.OnClickListener mClick = new View.OnClickListener() {
            public void onClick(View v) {
                switch (v.getId()) {


                }
            }
        };





    /**이미지 다운로드해서 가져오기 메서드 */
    private void downloadImg() {



        final String uid = user.getUid();
        Sign_up_profile.UserModel userModel = new Sign_up_profile.UserModel();
            StorageReference storageReference = mStorage.getReference()

                    .child("usersprofileImages").child("uid/"+uid);
        storageReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                @Override
                public void onSuccess(Uri uri) {
                    Sign_up_profile.UserModel userModel = new Sign_up_profile.UserModel();

                    Log.d("check", "성공"+uri);
                    Glide.with(HomeActivity.this)
                            .load(uri)
                            .into(my_profile_image);
                    //성공시 글라이드로 프사 띄우기
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception exception) {
                    Log.d("check", "실패"+uri);
                    //실패시
                }
            });

    }
}

