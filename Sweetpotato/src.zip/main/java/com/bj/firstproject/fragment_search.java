package com.bj.firstproject;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.bj.firstproject.recycle.CustomAdapter;
import com.bj.firstproject.recycle.User;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.annotations.Nullable;

import java.util.ArrayList;


public class fragment_search extends Fragment {
    Spinner spinner;
    private View view;
    TextView tv_spinner;
    Button btn_search; EditText et_search;
    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private ArrayList<User> arrayList;
    private FirebaseDatabase database;
    private DatabaseReference databaseReference;
    private FirebaseAuth mAuth;

    private String currentUId;

    private DatabaseReference usersDb;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_search,container,false);

        String searchOption = "username";


        spinner = (Spinner) view.findViewById(R.id.spinner); //fragment에서 findViewByid는 view.을 이용해서 사용

        btn_search = (Button) view.findViewById(R.id.btn_search);
        et_search = (EditText) view.findViewById(R.id.et_search);


        String[] items = {"닉네임", "전체"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(
                getActivity(), android.R.layout.simple_spinner_item, items );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        // 스피너에서 선택 했을 경우 이벤트 처리
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Log.d("check", items[position]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });




        btn_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String spinnerselected = spinner.getSelectedItem().toString();
                String search = et_search.getText().toString();

                if(spinnerselected.equals("닉네임")){
                    if (search.length()<2){
                        Toast.makeText(getActivity(), "두글자 이상으로 검색해주세요", Toast.LENGTH_SHORT).show();} else{
                        nicknamesearch();}
                }else if(spinnerselected.equals("전체")){
                    if (search.length()<2){
                        Toast.makeText(getActivity(), "두글자 이상으로 검색해주세요", Toast.LENGTH_SHORT).show();}
                    else{allsearch();}
                }
            }
        });


        return view;




    }

    public void nicknamesearch(){
        Log.d("check", "닉네임검색");

        String search = et_search.getText().toString(); // 게시글
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        mAuth = FirebaseAuth.getInstance();

        recyclerView = view.findViewById(R.id.recyclerView); // 아이디 연결
        recyclerView.setHasFixedSize(true); // 리사이클러뷰 기존 성능 강화
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        arrayList = new ArrayList<>(); // User 객체를 어댑터 쪽으로 담을 어레이 리스트

        database = FirebaseDatabase.getInstance(); // 파이어베이스 데이터베이스 연동








        final String uid = mAuth.getCurrentUser().getUid();
        databaseReference = database.getReference("contents").child("content"); // DB 테이블 연결

        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // 파이어베이스 데이터베이스의 데이터를 받아오는 곳
                arrayList.clear(); // 기존 배열리스트가 존재하지 않게 초기화
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) { //반복문으로 데이터 리스트를 추출
                    String snap = snapshot.getValue().toString();

                    // Generate a reference to a new location and add some data using push()

                    String key = databaseReference.push().getKey();
                    // Get the unique ID generated by a push()


                    if(
                            snap.contains(search)
                    ){

                        User user = snapshot.getValue(User.class); // User 객체에 데이터 담는다
                        arrayList.add(user); // 담은 데이터들을 배열리스트에 넣고 리사이클러뷰로 보낼 준비
                    }
                }
                adapter.notifyDataSetChanged(); // 리스트 저장 및 새로고침
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // db를 가져오던 중 에러 발생 시
                Log.e("MainActivity", String.valueOf(error.toException())); // 에러문 출력
                Log.d("check", "32");
            }
        });


        adapter = new CustomAdapter(arrayList, getActivity());


//        LayoutInflater layoutInflater = (LayoutInflater)getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
//        View view2 = layoutInflater.inflate(R.layout.post_item, null);  // fragment에서 post_item 레이아웃 위젯 사용




        recyclerView.setAdapter(adapter); // 리사이클러뷰에 어댑터 연결






    }
    public void allsearch(){
        Log.d("check", "전체검색");
        String search = et_search.getText().toString(); // 게시글
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        mAuth = FirebaseAuth.getInstance();

        recyclerView = view.findViewById(R.id.recyclerView); // 아이디 연결
        recyclerView.setHasFixedSize(true); // 리사이클러뷰 기존 성능 강화
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        arrayList = new ArrayList<>(); // User 객체를 어댑터 쪽으로 담을 어레이 리스트

        database = FirebaseDatabase.getInstance(); // 파이어베이스 데이터베이스 연동




        databaseReference = database.getReference("contents").child("content"); // DB 테이블 연결
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // 파이어베이스 데이터베이스의 데이터를 받아오는 곳
                arrayList.clear(); // 기존 배열리스트가 존재하지 않게 초기화
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) { //반복문으로 데이터 리스트를 추출
                    String snap = snapshot.getValue().toString();
                    if(
                            snap.contains(search)
                    ){
                        User user = snapshot.getValue(User.class); // User 객체에 데이터 담는다
                        arrayList.add(user); // 담은 데이터들을 배열리스트에 넣고 리사이클러뷰로 보낼 준비
                    }
                }
                adapter.notifyDataSetChanged(); // 리스트 저장 및 새로고침
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // db를 가져오던 중 에러 발생 시
                Log.e("MainActivity", String.valueOf(error.toException())); // 에러문 출력
            }
        });


        adapter = new CustomAdapter(arrayList, getActivity());


//        LayoutInflater layoutInflater = (LayoutInflater)getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
//        View view2 = layoutInflater.inflate(R.layout.post_item, null);  // fragment에서 post_item 레이아웃 위젯 사용




        recyclerView.setAdapter(adapter); // 리사이클러뷰에 어댑터 연결


    }



}