package com.bj.firstproject;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Terms_of_service extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.terms_of_service);
    }
}