package com.bj.firstproject;

import static android.content.ContentValues.TAG;

import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.content.CursorLoader;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.annotations.Nullable;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;


public class upload extends AppCompatActivity {


    public static class PostModel {

        public String myid; // 로그인한 아이디
        public String photo; // 게시글 사진
        public String photoName; // 게시글사진 이름(사진삭제할때 필요, 절대경로를 뜻함)
        public String contents; // 게시글 내용
        //        public String person; // 친구태그
        public String userprofileimage; // 회원가입시 프로필사진
        public String username; // 회원가입시 닉네임
        public int starCount = 0; // 좋아요 갯수
        public float starall = 0; //별점 총합
        public float star = starall/starCount; // 평균 별점
        public String comment;
        public Map<String, Boolean> stars = new HashMap<>(); // 별점 매긴사람
        // String 값은 아이디를 뜻하고, boolean 은 true

    }

    public static final int PICK_FROM_ALBUM = 1;
    private Uri imageUri;
    private String pathUri;
    private File tempFile;
    private FirebaseAuth mAuth;
    private FirebaseDatabase mDatabase;
    private FirebaseStorage mStorage;
    private Button btn_upload_post;
    ImageView iv_upload;
    EditText et_post_upload;
    String imageName2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.upload);


        // Authentication, Database, Storage 초기화
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        String name = user.getDisplayName();
        String email = user.getEmail();
        Uri photoUrl = user.getPhotoUrl();


        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance();
        mStorage = FirebaseStorage.getInstance();

        // 변수 할당
        et_post_upload = findViewById(R.id.et_post_upload);
        iv_upload = (ImageView) findViewById(R.id.iv_upload);
        iv_upload.setImageURI(imageUri);
        btn_upload_post = findViewById(R.id.btn_upload_post);




        iv_upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoAlbum();
                Log.d("check", "앨범가기");
            }
        });









        btn_upload_post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { upload();


            }


        });
    }
    // 앨범 메소드
    private void gotoAlbum() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType(MediaStore.Images.Media.CONTENT_TYPE);
        startActivityForResult(intent, PICK_FROM_ALBUM);
        Log.d("check", "앨범들어옴");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK) { // 코드가 틀릴경우
            Toast.makeText(upload.this, "취소되었습니다.", Toast.LENGTH_SHORT).show();
            if (tempFile != null) {
                if (tempFile.exists()) {
                    if (tempFile.delete()) {
                        Log.e(TAG, tempFile.getAbsolutePath() + " 삭제 성공");
                        tempFile = null;
                    }
                }
            }
            return;
        }

        switch (requestCode) {
            case PICK_FROM_ALBUM: { // 코드 일치
                // Uri
                imageUri = data.getData();
                Intent intent = new Intent(upload.this, upload.class);
                intent.putExtra("문자", imageUri); //'문자'라는 이름으로 main_text 전달
                pathUri = getPath(data.getData());
                Log.d("check", "pick from album" +imageUri);
//                photo_profile.setImageURI(imageUri); // 이미지 띄움
                iv_upload.setImageURI(imageUri);
                break;
            }
        }
    }
    // uri 절대경로 가져오기
    public String getPath(Uri uri) {

        String[] proj = {MediaStore.Images.Media.DATA};
        CursorLoader cursorLoader = new CursorLoader(this, uri, proj, null, null, null);
        Log.d("절대경로", "지나감");
        Cursor cursor = cursorLoader.loadInBackground();
        int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);

        cursor.moveToFirst();
        return cursor.getString(columnIndex);
    }

    public void upload() {

        final ProgressDialog mDialog = new ProgressDialog(upload.this);
        mDialog.setMessage("글 작성중입니다.");
        mDialog.show();


        String c = et_post_upload.getText().toString(); // 게시글


        final String uid = mAuth.getCurrentUser().getUid();
        final Uri file = Uri.fromFile(new File(pathUri)); // 절대경로uri를 file에 할당
        Log.d(TAG, "phto file : " + file);

        StorageReference storageReference = mStorage.getReference().child("userImages").child("uid/" + file.getLastPathSegment());
        storageReference.putFile(imageUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                final Task<Uri> imageUrl = task.getResult().getStorage().getDownloadUrl();
                while (!imageUrl.isComplete()) ;

                mDatabase.getReference().child("users").child(uid)
                        .addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                Sign_up_profile.UserModel userModel = dataSnapshot.getValue(Sign_up_profile.UserModel.class);
                                Log.d(TAG, "profileImageUrl" + userModel.profileImageUrl);
                                Log.d(TAG, "userName" + userModel.userName);

                                PostModel postModel = new PostModel();
                                Log.d("check", "PostModel 생성");
                                postModel.myid = uid;
                                postModel.photo = imageUrl.getResult().toString();
                                postModel.userprofileimage = userModel.profileImageUrl;
                                postModel.photoName = file.getLastPathSegment();
                                postModel.contents = c;
                                postModel.username = userModel.userName;
                                postModel.star = 0;
                                // 게시글 내용 저장
                                mDatabase.getReference().child("contents").child("content").push()
                                        .setValue(postModel).addOnSuccessListener(new OnSuccessListener<Void>() {
                                            @Override
                                            public void onSuccess(Void aVoid) {
                                                Intent uploadfinish = new Intent(upload.this, HomeActivity.class);
                                                startActivity(uploadfinish);
                                                Toast.makeText(upload.this, "글 작성에 성공했습니다.", Toast.LENGTH_SHORT).show();
                                                mDialog.dismiss();
                                                Log.d("check", "게시글 내용 저장성공");
                                                finish();
                                            }
                                        });
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                Toast.makeText(upload.this, "오류로인해 실패했습니다..", Toast.LENGTH_SHORT).show();
                                mDialog.dismiss();
                            }
                        });

            }
        });



    }

}