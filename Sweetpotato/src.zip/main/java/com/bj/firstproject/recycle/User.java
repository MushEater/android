package com.bj.firstproject.recycle;

import android.net.Uri;

import java.util.HashMap;
import java.util.Map;

public class User {


        public String myid; // 로그인한 아이디
        public String photo; // 게시글 사진
        public String photoName; // 게시글사진 이름(사진삭제할때 필요, 절대경로를 뜻함)
        public String contents; // 게시글 내용
        //        public String person; // 친구태그
        public String userprofileimage; // 회원가입시 프로필사진
        public String username; // 회원가입시 닉네임
        public int starCount = 0; // 별점매긴횟수
        public float starall = 0; //별점 총합
        public float star = 0; // 평균 별점
        public Map<String, Boolean> stars = new HashMap<>(); // 별점 매긴사람
        public String comment;



    public float getStarall() {
        return starall;
    }

    public void setStarall(float starall) {
        this.starall = starall;
    }

    public float getStar() {
        return star;
    }

    public void setStar(float star) {
        this.star = star;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
// String 값은 아이디를 뜻하고, boolean 은 true


    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getPhotoName() {
        return photoName;
    }

    public void setPhotoName(String photoName) {
        this.photoName = photoName;
    }

    public String getContents() {
        return contents;
    }

    public void setContents(String contents) {
        this.contents = contents;
    }

    public String getUserprofileimage() {
        return userprofileimage;
    }

    public void setUserprofileimage(String userprofileimage) {
        this.userprofileimage = userprofileimage;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getStarCount() {
        return starCount;
    }

    public void setStarCount(int starCount) {
        this.starCount = starCount;
    }

    public Map<String, Boolean> getStars() {
        return stars;
    }

    public void setStars(Map<String, Boolean> stars) {
        this.stars = stars;
    }

    public String getMyid() {
        return myid;
    }

    public void setMyid(String myid) {
        this.myid = myid;
    }
}
