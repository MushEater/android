package com.bj.firstproject.recycle;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bj.firstproject.R;
import com.bj.firstproject.fragment_home;
import com.bumptech.glide.Glide;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.CustomViewHolder>  {

    private ArrayList<User> arrayList;
    private Context context;








    //===== [Click 이벤트 구현을 위해 추가된 코드] ==========================
    // OnItemClickListener 인터페이스 선언
    public interface OnItemClickListener {
        void onItemClicked(int position, String data);
    }

    // OnItemClickListener 참조 변수 선언
    private OnItemClickListener itemClickListener;

    // OnItemClickListener 전달 메소드
    public void setOnItemClickListener (OnItemClickListener listener) {
        itemClickListener = listener;
    }

    public CustomAdapter(ArrayList<User> arrayList, Context context) {
        this.arrayList = arrayList;
        this.context = context;
    }
    //----- 뷰홀더 클래스 ---------------------------------------------------
    public static class ViewHolder extends RecyclerView.ViewHolder {
        private TextView textView;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.tv_comment);
        }

        public TextView getTextView() {
            return textView;
        }

        public void setTextView(TextView textView) {
            this.textView = textView;
        }
    }


    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.post_item, parent, false);
        CustomViewHolder holder = new CustomViewHolder(view);



        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder holder, int position) {
        Glide.with(holder.itemView)
                .load(arrayList.get(position).getUserprofileimage())
                .into(holder.iv_profile);
        Glide.with(holder.itemView)
                .load(arrayList.get(position).getPhoto())
                .into(holder.post_image);

        holder.tv_post.setText(arrayList.get(position).getContents());
        holder.tv_rating.setText(arrayList.get(position).getStar()+"");
        holder.tv_userName.setText(arrayList.get(position).getUsername());
        holder.tv_comment.setText(arrayList.get(position).getComment());
    }

    @Override
    public int getItemCount() {
        return (arrayList != null ? arrayList.size() : 0);
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder {
        CircleImageView iv_profile; ImageView post_image;
        TextView tv_post; TextView tv_comment;
        TextView tv_userName;   Button btn_comment; EditText et_comment;
        TextView tv_rating;
        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);


            this.btn_comment = itemView.findViewById(R.id.btn_comment);
            this.post_image = itemView.findViewById(R.id.post_image);
            this.iv_profile = itemView.findViewById(R.id.iv_profile);
            this.tv_post = itemView.findViewById(R.id.tv_post);
            this.tv_userName = itemView.findViewById(R.id.tv_username);
            this.tv_comment = itemView.findViewById(R.id.tv_comment);
            this.et_comment = itemView.findViewById(R.id.et_comment);
            this.tv_rating = itemView.findViewById(R.id.tv_rating);










        }
    }



}