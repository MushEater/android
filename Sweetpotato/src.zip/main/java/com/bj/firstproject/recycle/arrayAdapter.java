package com.bj.firstproject.recycle;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bj.firstproject.R;
import com.bumptech.glide.Glide;


import java.util.List;

/**
 * Created by manel on 9/5/2017.
 */

public class arrayAdapter extends ArrayAdapter<cards>{

    Context context;

    public arrayAdapter(Context context, int resourceId, List<cards> items){
        super(context, resourceId, items);
    }
    public View getView(int position, View convertView, ViewGroup parent){
        cards card_item = getItem(position);

        if (convertView == null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.post_item, parent, false);
        }

        TextView tv_username = (TextView) convertView.findViewById(R.id.tv_username);
        ImageView post_image = (ImageView) convertView.findViewById(R.id.post_image);

        tv_username.setText(card_item.getName());
        switch(card_item.getProfileImageUrl()){
            case "default":
                Glide.with(convertView.getContext()).load(R.mipmap.ic_launcher).into(post_image);
                break;
            default:

                Glide.with(convertView.getContext()).load(card_item.getProfileImageUrl()).into(post_image);
                break;
        }


        return convertView;

    }
}
