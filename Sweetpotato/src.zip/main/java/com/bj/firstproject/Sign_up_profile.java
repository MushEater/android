package com.bj.firstproject;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.content.CursorLoader;

import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.annotations.Nullable;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.File;
import java.util.ArrayList;
import java.util.Random;

import de.hdodenhof.circleimageview.CircleImageView;


public class Sign_up_profile extends AppCompatActivity {

    EditText etnickname_input, etphone_input, etage_input;

    public static class UserModel {
        // 사용자 기본정보

        public String userName; // 사용자 이름(닉네임)
        public String profileImageUrl; // 사용자 프로필사진
        public String uid; // 현재 사용자(로그인한)
        public String PhoneNumber;
        public String Age;


//    public String pushToken;

    }

    public static final int PICK_FROM_ALBUM = 1;
    private Uri imageUri;
    private String pathUri;
    private File tempFile;
    private FirebaseAuth mAuth;
    private FirebaseDatabase mDatabase;
    private FirebaseStorage mStorage;
    CircleImageView photo_profile;
    private Button btn_profile_make;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up_profile);

        // Authentication, Database, Storage 초기화
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance();
        mStorage = FirebaseStorage.getInstance();


        // 변수 할당
        etnickname_input = findViewById(R.id.etnickname_input);
        etphone_input = findViewById(R.id.etphone_input);
        etage_input = findViewById(R.id.etage_input);
        photo_profile = (CircleImageView) findViewById(R.id.photo_profile);
        photo_profile.setImageURI(imageUri);
        btn_profile_make = findViewById(R.id.btn_profile_make);

        btn_profile_make.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signup();
            }
        });

        photo_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoAlbum();
                Log.d("check", "앨범가기");
            }
        });
    }

    // 앨범 메소드
    private void gotoAlbum() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType(MediaStore.Images.Media.CONTENT_TYPE);
        startActivityForResult(intent, PICK_FROM_ALBUM);
        Log.d("check", "앨범들어옴");
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK) { // 코드가 틀릴경우
            Toast.makeText(Sign_up_profile.this, "취소되었습니다.", Toast.LENGTH_SHORT).show();
            if (tempFile != null) {
                if (tempFile.exists()) {
                    if (tempFile.delete()) {
                        Log.e(TAG, tempFile.getAbsolutePath() + "삭제 성공");
                        tempFile = null;
                    }
                }
            }
            return;
        }

        switch (requestCode) {
            case PICK_FROM_ALBUM: { // 코드 일치
                // Uri
                imageUri = data.getData();
                pathUri = getPath(data.getData());
                Log.d("check", "pick from album" +imageUri);
//                photo_profile.setImageURI(imageUri); // 이미지 띄움
                photo_profile.setImageURI(imageUri);
                break;
            }
        }
    }

    // uri 절대경로 가져오기
    public String getPath(Uri uri) {

        String[] proj = {MediaStore.Images.Media.DATA};
        CursorLoader cursorLoader = new CursorLoader(this, uri, proj, null, null, null);
        Log.d("절대경로", "지나감");
        Cursor cursor = cursorLoader.loadInBackground();
        int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);

        cursor.moveToFirst();
        return cursor.getString(columnIndex);
    }

    // 회원가입 로직
    private void signup() {
        String username = etnickname_input.getText().toString();
        String phone = etphone_input.getText().toString();
        String age = etage_input.getText().toString();

        // 프로필사진,이름,이메일,비밀번호 중 하나라도 비었으면 return
        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(phone) ||
                TextUtils.isEmpty(age)|| photo_profile == null ) {
            Toast.makeText(Sign_up_profile.this, "정보를 바르게 입력해주세요.", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            // Authentication에 email,pw 생성
            mAuth.createUserWithEmailAndPassword(username, phone)
                    .addOnCompleteListener

                            (Sign_up_profile.this, new OnCompleteListener<AuthResult>() {

                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    Log.d("check", "회원가입시도");
                                    if (task.isSuccessful()) { // 회원가입 성공시

                                        // uid에 task, 선택된 사진을 file에 할당
                                        Log.d("check", "회원가입시도 성공");
                                        final String uid = task.getResult().getUser().getUid();
                                        final Uri file = Uri.fromFile(new File(pathUri)); // path
                                        Log.d("check", "uid에 사진할당");
                                        // 스토리지에 방생성 후 선택한 이미지 넣음
                                        StorageReference storageReference = mStorage.getReference()
                                                .child("usersprofileImages").child("uid/"+file.getLastPathSegment());
                                        storageReference.putFile(imageUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
                                            @Override
                                            public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
                                                final Task<Uri> imageUrl = task.getResult().getStorage().getDownloadUrl();
                                                while (!imageUrl.isComplete()) ;

                                                UserModel userModel = new UserModel();
                                                Log.d("check", "userModel");
                                                userModel.userName = username;
                                                userModel.uid = uid;
                                                userModel.profileImageUrl = imageUrl.getResult().toString();

                                                // database에 저장
                                                Log.d("check", "db저장");
                                                mDatabase.getReference().child("users").child(uid)
                                                        .setValue(userModel);
                                            }

                                        });

                                        Toast.makeText(Sign_up_profile.this, "회원가입에 성공했습니다..", Toast.LENGTH_SHORT).show();
                                        Intent profilemake_emailpassword = new Intent(Sign_up_profile.this, HomeActivity.class);
                                        startActivity(profilemake_emailpassword);

                                    } else {
                                        if (task.getException() != null) { // 회원가입 실패시
                                            Log.d("check", "가입실패");
                                            Toast.makeText(Sign_up_profile.this, "가입에 실패했습니다.", Toast.LENGTH_SHORT).show();
                                            Log.d(TAG, "createUserWithEmail:failure");
                                        }
                                    }
                                }
                            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}