package com.bj.firstproject;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

public class fragment_updown extends Fragment {
    Button btn_choose; Button btn_updown;
    private View view; ImageView finalimage;
    int count=0;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_updown,container,false);

        btn_choose = (Button) view.findViewById(R.id.btn_choose);
        btn_updown = (Button) view.findViewById(R.id.btn_updown);
        finalimage = (ImageView) view.findViewById(R.id.finalimage);



        btn_choose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                count = 0;
                finalimage.setImageResource(R.drawable.updown_1);
                Log.d("check", "choose");
            }
        });
        btn_updown.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("check", "updown");
                count =0;
                if(count == 0){
                    finalimage.setImageResource(R.drawable.vsfinal1);
                    count ++;
                }

            }
        });
        finalimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("check", "전환");

                if(count == 0){
                }else{
                    finalimage.setImageResource(R.drawable.vsfinal2);
                }

            }
        });







        return view;
    }
}